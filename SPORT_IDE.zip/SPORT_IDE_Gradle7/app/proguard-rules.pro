# SPORT IDE starter: keep project rules here when adding libraries.
