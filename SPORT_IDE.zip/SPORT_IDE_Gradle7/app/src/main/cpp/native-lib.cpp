#include <jni.h>
#include <string>

extern "C"
JNIEXPORT jstring JNICALL
Java_com_sport_ide_MainActivity_nativeBuildInfo(JNIEnv* env, jobject /* this */) {
    std::string info = "SPORT IDE native module is loaded";
    return env->NewStringUTF(info.c_str());
}
