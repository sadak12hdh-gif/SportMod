package com.sport.ide;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;

import androidx.documentfile.provider.DocumentFile;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Read-only project scanner. It never edits project files.
 * Reports common Gradle/AGP/JDK/SDK/NDK compatibility indicators.
 */
public final class ProjectAnalyzer {
    private ProjectAnalyzer() {}

    public static String analyze(Context context, Uri treeUri) {
        if (treeUri == null) return "اختَر مجلد مشروع أولاً.";
        DocumentFile root = DocumentFile.fromTreeUri(context, treeUri);
        if (root == null || !root.isDirectory()) return "تعذر الوصول إلى مجلد المشروع.";

        List<DocumentFile> found = new ArrayList<>();
        walk(root, found, 0);
        StringBuilder out = new StringBuilder();
        out.append("نتيجة فحص SPORT IDE\n");
        out.append("====================\n");
        out.append("عدد الملفات المفحوصة: ").append(found.size()).append("\n\n");

        String wrapper = null, rootGradle = null, appGradle = null, props = null, cmake = null, manifest = null;
        int gradleFiles = 0;
        for (DocumentFile f : found) {
            String n = f.getName() == null ? "" : f.getName();
            if (n.equals("gradle-wrapper.properties")) wrapper = read(context, f.getUri());
            else if (n.equals("build.gradle") || n.equals("build.gradle.kts")) {
                gradleFiles++;
                if (rootGradle == null) rootGradle = read(context, f.getUri());
                if (n.equals("build.gradle") && f.getUri().toString().contains("/app/")) appGradle = read(context, f.getUri());
            } else if (n.equals("gradle.properties")) props = read(context, f.getUri());
            else if (n.equals("CMakeLists.txt")) cmake = read(context, f.getUri());
            else if (n.equals("AndroidManifest.xml")) manifest = read(context, f.getUri());
        }

        out.append("ملفات البناء: ").append(gradleFiles).append(" ملف Gradle\n");
        if (wrapper != null) {
            String gradle = match(wrapper, "gradle-([0-9]+(?:\\.[0-9]+){1,3})-(?:all|bin)\\.zip");
            out.append("Gradle Wrapper: ").append(gradle == null ? "موجود، تعذر قراءة الإصدار" : gradle).append("\n");
        } else {
            out.append("Gradle Wrapper: غير موجود — قد يعتمد المشروع على إصدار مثبت خارجياً.\n");
        }

        String combined = (rootGradle == null ? "" : rootGradle) + "\n" +
                          (appGradle == null ? "" : appGradle);
        String agp = match(combined, "com\\.android\\.application[^\n]{0,100}?version\\s*[=( ]+['\\\"]([0-9]+(?:\\.[0-9]+){1,3})");
        if (agp == null) agp = match(combined, "com\\.android\\.tools\\.build:gradle:([0-9]+(?:\\.[0-9]+){1,3})");
        out.append("Android Gradle Plugin: ").append(agp == null ? "غير محدد من الملفات المقروءة" : agp).append("\n");

        String jvm = match(combined, "(?:jvmTarget|JavaVersion\\.VERSION_|VERSION_)(?:\\s*=?\\s*|\\s*)(?:['\\\"])?(1\\.[0-9]+|[0-9]{1,2})");
        out.append("إعداد Java/JVM: ").append(jvm == null ? "غير واضح؛ راجع compileOptions وkotlinOptions" : jvm).append("\n");
        String sdk = match(combined, "compileSdk(?:Version)?\\s*(?:=\\s*)?([0-9]{2,3})");
        out.append("compileSdk: ").append(sdk == null ? "غير محدد بوضوح" : sdk).append("\n");
        String ndk = match(combined, "ndkVersion\\s*(?:=\\s*)?['\\\"]([^'\\\"]+)['\\\"]");
        out.append("NDK version: ").append(ndk == null ? "غير مثبتة صراحةً بالمشروع" : ndk).append("\n");

        boolean abi32 = combined.contains("armeabi-v7a");
        boolean abi64 = combined.contains("arm64-v8a");
        out.append("ABI 32-bit armeabi-v7a: ").append(abi32 ? "مذكورة" : "غير مكتشفة في ملفات Gradle المقروءة").append("\n");
        out.append("ABI 64-bit arm64-v8a: ").append(abi64 ? "مذكورة" : "غير مكتشفة في ملفات Gradle المقروءة").append("\n");
        out.append("CMake: ").append(cmake == null ? "لم يُعثر على CMakeLists.txt" : "تم العثور على CMakeLists.txt").append("\n");
        out.append("Manifest: ").append(manifest == null ? "لم يُعثر على AndroidManifest.xml" : "تم العثور على AndroidManifest.xml").append("\n\n");

        out.append("ملاحظات التوافق\n");
        out.append("• هذا فحص ساكن للملفات المتاحة فقط، وليس تجربة بناء فعلية.\n");
        out.append("• يجب مطابقة Gradle مع إصدار Android Gradle Plugin، ومطابقة JDK مع الاثنين.\n");
        out.append("• إذا كان المشروع يستخدم Kotlin أو Flutter أو React Native أو Unity فقد توجد متطلبات إضافية.\n");
        out.append("• لا تغيّر إصدارات المشروع تلقائياً قبل إنشاء نسخة احتياطية ومراجعة سجل البناء.\n");
        out.append("• لم يتم تعديل أي ملف من ملفات المشروع أثناء الفحص.\n");
        return out.toString();
    }

    private static void walk(DocumentFile dir, List<DocumentFile> out, int depth) {
        if (depth > 12 || out.size() > 5000) return;
        DocumentFile[] children = dir.listFiles();
        for (DocumentFile f : children) {
            String n = f.getName() == null ? "" : f.getName();
            if (f.isDirectory()) {
                if (n.equals(".git") || n.equals(".gradle") || n.equals("build") || n.equals("node_modules")) continue;
                walk(f, out, depth + 1);
            } else if (f.isFile()) {
                out.add(f);
            }
        }
    }

    private static String read(Context c, Uri uri) {
        try (InputStream in = c.getContentResolver().openInputStream(uri);
             BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder b = new StringBuilder();
            String line;
            int chars = 0;
            while ((line = r.readLine()) != null && chars < 300000) {
                b.append(line).append('\n');
                chars += line.length();
            }
            return b.toString();
        } catch (Exception e) { return ""; }
    }

    private static String match(String source, String regex) {
        Matcher m = Pattern.compile(regex, Pattern.MULTILINE).matcher(source);
        return m.find() ? m.group(1) : null;
    }
}
