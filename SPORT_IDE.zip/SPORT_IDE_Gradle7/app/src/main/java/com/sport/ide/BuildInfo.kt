package com.sport.ide

/** Kotlin starter source for SPORT IDE. */
object BuildInfo {
    const val VERSION: String = "1.0.0"
    const val SUPPORTED_ABIS: String = "armeabi-v7a, arm64-v8a"
}
