package com.sport.ide;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.documentfile.provider.DocumentFile;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int PICK_PROJECT = 4101;
    private static final int PICK_FILE = 4102;
    private static final int CREATE_FILE = 4103;

    private final int bg = Color.rgb(8, 13, 23);
    private final int panel = Color.rgb(17, 27, 43);
    private final int cyan = Color.rgb(0, 190, 255);
    private final int white = Color.rgb(236, 244, 255);
    private final int muted = Color.rgb(155, 174, 198);

    private LinearLayout root, body, header;
    private EditText editor;
    private TextView status, currentFile;
    private Uri projectUri, fileUri;
    private String openedName = "لم يتم فتح ملف";
    private boolean editorVisible = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildHome();
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private void pad(View v, int all) {
        v.setPadding(dp(all), dp(all), dp(all), dp(all));
    }

    private Button button(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(white);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel));
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private void addButton(LinearLayout parent, String label, Runnable action) {
        Button b = button(label, action);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(4), 0, dp(4));
        parent.addView(b, lp);
    }

    private void buildShell(String title) {
        root = column();
        root.setBackgroundColor(bg);
        setContentView(root);

        header = row();
        header.setBackgroundColor(panel);
        pad(header, 14);
        TextView brand = text("◆ SPORT IDE", 21, cyan, true);
        header.addView(brand, new LinearLayout.LayoutParams(0, dp(42), 1));
        TextView ver = text("v1.0 • ANDROID", 11, muted, true);
        header.addView(ver);
        root.addView(header);

        TextView page = text(title, 19, white, true);
        page.setPadding(dp(16), dp(12), dp(16), dp(8));
        root.addView(page);

        ScrollView scroll = new ScrollView(this);
        body = column();
        body.setPadding(dp(14), dp(4), dp(14), dp(18));
        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        status = text("جاهز • اختَر مشروعاً للبدء", 12, muted, false);
        status.setPadding(dp(14), dp(10), dp(14), dp(10));
        status.setBackgroundColor(panel);
        root.addView(status);
    }

    private void buildHome() {
        buildShell("بيئة التطوير المحمولة");
        TextView hero = text("CODE  •  BUILD  •  PLAY\nاكتب الكود وابنِ مشروعك من الهاتف", 18, white, true);
        hero.setGravity(Gravity.CENTER);
        hero.setBackgroundColor(Color.rgb(12, 31, 51));
        hero.setPadding(dp(12), dp(24), dp(12), dp(24));
        body.addView(hero);

        TextView chips = text("JAVA  •  KOTLIN  •  C/C++  •  NDK\n32-bit ARMv7  |  64-bit ARM64", 13, cyan, true);
        chips.setGravity(Gravity.CENTER);
        chips.setPadding(dp(8), dp(12), dp(8), dp(12));
        body.addView(chips);

        addButton(body, "📂  فتح مجلد مشروع", this::pickProject);
        addButton(body, "📝  فتح ملف للكود", this::pickFile);
        addButton(body, "💾  حفظ الملف المفتوح", this::saveFile);
        addButton(body, "🔎  فحص توافق السورس تلقائياً", this::showProjectAnalysis);
        addButton(body, "⚙️  إعدادات البناء وأوامر Gradle", this::showBuildInfo);
        addButton(body, "🧩  مثال C++ / NDK", this::showNativeInfo);
        addButton(body, "ℹ️  حول SPORT IDE", this::showAbout);

        TextView note = text(
            "النسخة الأولى العملية: اختيار ملفات عبر منتقي أندرويد، تحرير النص وحفظه، " +
            "وقالب NDK مضمّن بالمصدر. محرك بناء Gradle/SDK غير مضمّن داخل التطبيق؛ " +
            "استخدم AndroidIDE أو بيئة Android SDK لبناء المشاريع.",
            13, muted, false);
        note.setPadding(dp(8), dp(16), dp(8), dp(8));
        body.addView(note);
    }

    private void pickProject() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                   Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                   Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, PICK_PROJECT);
    }

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("*/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                   Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                   Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, PICK_FILE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (Exception ignored) { }
        if (requestCode == PICK_PROJECT) {
            projectUri = uri;
            DocumentFile dir = DocumentFile.fromTreeUri(this, uri);
            String name = dir != null ? dir.getName() : "Project";
            status.setText("المشروع المحدد: " + name);
            Toast.makeText(this, "تم اختيار مجلد المشروع. افتح ملفاً من زر فتح ملف للكود.", Toast.LENGTH_LONG).show();
        } else if (requestCode == PICK_FILE) {
            fileUri = uri;
            openedName = uri.getLastPathSegment() == null ? "source.txt" : uri.getLastPathSegment();
            readFile();
        }
    }

    private void readFile() {
        try (InputStream in = getContentResolver().openInputStream(fileUri);
             BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line).append('\n');
            showEditor(sb.toString());
            status.setText("مفتوح: " + openedName);
        } catch (Exception e) {
            toast("تعذر فتح الملف: " + e.getMessage());
        }
    }

    private void showEditor(String contents) {
        editorVisible = true;
        buildShell("محرر الملفات");
        currentFile = text("📄 " + openedName, 14, cyan, true);
        body.addView(currentFile);
        editor = new EditText(this);
        editor.setGravity(Gravity.TOP | Gravity.START);
        editor.setTextColor(white);
        editor.setHintTextColor(muted);
        editor.setHint("اكتب الكود هنا...");
        editor.setTextSize(13);
        editor.setTypeface(Typeface.MONOSPACE);
        editor.setSingleLine(false);
        editor.setHorizontallyScrolling(true);
        editor.setPadding(dp(12), dp(12), dp(12), dp(12));
        editor.setBackgroundColor(Color.rgb(5, 10, 18));
        editor.setText(contents);
        body.addView(editor, new LinearLayout.LayoutParams(-1, dp(420)));
        addButton(body, "💾 حفظ التعديلات", this::saveFile);
        addButton(body, "↩ رجوع للرئيسية", this::buildHome);
    }

    private void saveFile() {
        if (fileUri == null || editor == null) {
            toast("افتح ملفاً أولاً حتى تحفظ التعديلات.");
            return;
        }
        try (OutputStream out = getContentResolver().openOutputStream(fileUri, "wt")) {
            out.write(editor.getText().toString().getBytes(StandardCharsets.UTF_8));
            out.flush();
            status.setText("تم حفظ: " + openedName);
            toast("تم حفظ الملف");
        } catch (Exception e) {
            toast("فشل الحفظ: " + e.getMessage());
        }
    }


    private void showProjectAnalysis() {
        buildShell("فحص توافق المشروع");
        if (projectUri == null) {
            addInfo("لا يوجد مشروع محدد", "اضغط «فتح مجلد مشروع» أولاً، ثم ارجع واضغط فحص التوافق.");
            addButton(body, "اختيار مجلد مشروع", this::pickProject);
            addButton(body, "رجوع", this::buildHome);
            return;
        }
        addInfo("الفحص للقراءة فقط", "لن يتم تغيير أو حذف أي ملف. افحص المشروع قبل محاولة تحديث Gradle أو JDK.");
        TextView result = text(ProjectAnalyzer.analyze(this, projectUri), 12, white, false);
        result.setTypeface(Typeface.MONOSPACE);
        result.setGravity(Gravity.TOP | Gravity.START);
        result.setPadding(dp(12), dp(12), dp(12), dp(12));
        result.setBackgroundColor(Color.rgb(5, 10, 18));
        body.addView(result, new LinearLayout.LayoutParams(-1, -2));
        addButton(body, "إعادة الفحص", this::showProjectAnalysis);
        addButton(body, "رجوع للرئيسية", this::buildHome);
    }

    private void showBuildInfo() {
        buildShell("إعدادات البناء");
        addInfo("معماريات ARM", "armeabi-v7a (32-bit) و arm64-v8a (64-bit) مهيأة في app/build.gradle.kts.");
        addInfo("متطلبات البناء", "JDK 17، Android SDK 35، Android Build Tools، NDK وCMake 3.22.1.");
        addInfo("أوامر البناء", "./gradlew assembleDebug\n./gradlew assembleRelease\n./gradlew bundleRelease");
        addInfo("تنبيه", "هذه الشاشة تعرض إعدادات وأوامر البناء؛ التطبيق لا ينفذ Gradle داخلياً ولا يحتوي SDK/NDK كاملين.");
        addButton(body, "نسخ أوامر البناء", () -> {
            android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("Gradle", "./gradlew assembleDebug\n./gradlew assembleRelease"));
            toast("تم نسخ الأوامر");
        });
        addButton(body, "رجوع", this::buildHome);
    }

    private void showNativeInfo() {
        buildShell("مثال C++ / NDK");
        addInfo("ملف المثال", "app/src/main/cpp/native-lib.cpp");
        addInfo("CMake", "app/src/main/cpp/CMakeLists.txt");
        addInfo("ABI", "يُبنى المكتبة الأصلية لكل من armeabi-v7a و arm64-v8a عند تثبيت NDK الصحيح.");
        addInfo("الخطوة التالية", "يمكن ربط الدوال الأصلية من Java/JNI عند إضافة ميزات المشروع.");
        addButton(body, "رجوع", this::buildHome);
    }

    private void showAbout() {
        buildShell("حول SPORT IDE");
        addInfo("الإصدار", "SPORT IDE Starter 1.0.0");
        addInfo("الموجود حالياً", "واجهة أصلية، فتح ملف من منتقي النظام، محرر نصوص وحفظ، إعدادات ABI، وقالب CMake/NDK.");
        addInfo("غير موجود بعد", "محرر متعدد التبويبات، إكمال تلقائي، Git، طرفية حقيقية، تنزيل SDK، وتشغيل Gradle من داخل التطبيق.");
        addButton(body, "رجوع", this::buildHome);
    }

    private void addInfo(String title, String value) {
        LinearLayout card = column();
        card.setBackgroundColor(panel);
        card.setPadding(dp(12), dp(10), dp(12), dp(10));
        TextView h = text(title, 15, cyan, true);
        card.addView(h);
        TextView v = text(value, 13, white, false);
        v.setGravity(Gravity.TOP | Gravity.START);
        v.setPadding(0, dp(6), 0, 0);
        card.addView(v);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(5), 0, dp(5));
        body.addView(card, lp);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }
}
